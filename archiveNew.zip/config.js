const config = {
    owner: ['6282295258707@s.whatsapp.net'], // make format nomormu@s.whatsapp.net
};

module.exports = config;
